#!/user/bin/env python
# -*- coding: utf-8 -*-

"""
------------------------------------
@Project : testkeeper
@Time    : 12:44
@Auth    : 成都-阿木木
@Email   : 848257135@qq.com
@File    : tkdecorator.py
@IDE     : PyCharm
------------------------------------
"""


def plan(plan_name: str):
    ...


def job(job_name: str):
    ...


def step(step_name: str):
    ...
