#!/user/bin/env python
# -*- coding: utf-8 -*-

"""
------------------------------------
@Project : testkeeper
@Time    : 16:29
@Auth    : 成都-阿木木
@Email   : 848257135@qq.com
@File    : main.py
@IDE     : PyCharm
------------------------------------
"""
from loguru import logger


class Runner:
    def __init__(self, parser):
        self.parser = parser

    def run(self):
        ...


