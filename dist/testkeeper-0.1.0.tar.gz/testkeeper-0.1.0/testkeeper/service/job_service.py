#!/user/bin/env python
# -*- coding: utf-8 -*-

"""
------------------------------------
@Project : testkeeper
@Time    : 11:46
@Auth    : 成都-阿木木
@Email   : 848257135@qq.com
@File    : job_service.py
@IDE     : PyCharm
------------------------------------
"""
